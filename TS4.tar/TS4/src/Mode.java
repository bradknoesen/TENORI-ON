/*
 * interface with method referenced in every Mode
 *
 * @authors David Olagunju
 */
public interface Mode {

    public abstract void soundButtonOperation(SoundButton button);

    public abstract void okButtonOperation();

}
/*
 * Changes the layer the tenori is currently displaying.
 *
 * @authors Bradley Knoesen, David Olagunju
 */
public class ChangeLayerMode implements Mode {

	int layerNum;
	
    public ChangeLayerMode(){
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button) {   	
    	button.getTenori().rowHighLight(button.getXCoord()); //X coord
    	this.layerNum = button.getXCoord();
    	String temp = String.valueOf(button.getXCoord()+1);
    	Device.getInstance().getTenori().LCD.setText(temp);    
    }


	@Override
	public void okButtonOperation() {
		System.out.println("Layer " + this.layerNum + " has been selected");
		Device.getInstance().setCurrentLayer(layerNum);
		
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
}
/*
 * OffMode class is the default class for when Tenori instantiated 
 * @author Presley Kode
 */
public class OffMode implements Mode 
{
    public OffMode() {
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button)
    {
        System.out.println("Matrix button cannot be processed in OnOffMode");
        System.out.println("Please turn on Tenori");
    }

    @Override 
    public void okButtonOperation(){}
}
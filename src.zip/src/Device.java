/*
 * Device acts as the back end of the GUI (tenori).It uses the singleton design pattern to enable methods 
 * to be referenced by various other classes using a single instance.
 * 
 * @authors Bradley Knoesen, Presley Kode, Kate Mawbey, Eneida Morina, David Olagunju.
 */
public class Device
{
	
    private volatile static Device instance = null;
    private Mode mode = new OffMode();
    private Layer[] layers = new Layer[16];
    private Layer tempLayer;
    private Tenori tenori;
    private static ClockHand clockHand;
    private MediaPlayer mediaPlayer;

    
    /*
     * Constructor to create a new Device with all the variables needed to 
     * 
     * @authors Kate Mawbey, Eneida Morina
     */  
    public Device(){
    	mode = new OffMode();
    	for (int i = 0; i<16;i++)
    	{
    		layers[i] = new Layer();		//edit code here: only create layer on request by user
    	}	
    	
    	mediaPlayer = new MediaPlayer();
    	tempLayer = layers[0];
    	tenori = Tenori.makeGUI();
    }
    
    /*
     * Thread Safe Method to returns Device only if there isn't an instance already created
     * 
     * @authors David Olagunju.
     */ 
    public static Device getInstance(){
    	if(instance == null){
    		synchronized (Device.class){
    			if(instance == null){            
    				instance = new Device();
    			}
    		}
    	}
    	return instance;
    }
    
    public MediaPlayer getMediaPlayer()
    {
    	return this.mediaPlayer;
    }
    
    /*
     * Sets the Mode variable value using mode value defined in the parameters
     * 
     * @authors Bradley Knoesen
     */
    public void setMode(Mode mode) {
        this.mode = mode;
    }
    
    
    /*
     * Returns the Mode variable
     * 
     * @authors Bradley Knoesen
     */
    public Mode getMode() {
        return mode;
    }

    /*
     * Returns the Tenori
     * 
     * @authors Presley Kode
     */
    public Tenori getTenori()
    {
        return tenori;
    }

    /*
     * Returns the clockHand variable
     * 
     * @authors Presley Kode.
     */
   public static ClockHand getClockHand(){
   	return clockHand;
   }

   /*
    * Sets the clockHand variable value using ClockHand value defined in the parameters
    * 
    * @authors Presley Kode.
    */
   public static void setClockHand(ClockHand clockH)
   {
   	clockHand = clockH;
   }

   /*
    * Resets the Device to a default state 
    * 
    * @David Olagunju, Bradley Knoesen
    */
   	public void defaultState() 
   	{
	   mode = new OffMode();
	   setClockHand(new ClockHand());
	   tenori.LCD.setText(null);
	   mediaPlayer = new MediaPlayer(); 
   }

	public Layer getTempLayer(int layerNum) 
	{	
		return this.tempLayer;
	}
	
	public Layer getTempLayer(){
		return tempLayer;
	}
	
	public int findLayer(Layer tempLayer){
		int layerIndex = -1;
		for (int i = 0; i < layers.length; i ++){
			if (tempLayer == layers[i]) {
				layerIndex = i;
			}
		}
		return layerIndex;
	}
	
	public Layer getLayer(int i)
	{
		return this.layers[i];
	}

	public Layer[] getLayers() 
	{
		return this.layers;
	}

	public void setCurrentLayer(int layerNum)
	{
		this.tempLayer = this.layers[layerNum];
	}	

	public void setLayer(Layer lay)
	{
		this.tempLayer = lay;
	}
}

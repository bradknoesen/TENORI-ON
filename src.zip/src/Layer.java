/*
 * Stores an array of states. O == On and X == Off to check if a soundbutton has been clicked on or not.
 * Char has been used to save space  
 *
 * @authors Bradley Knoesen, David Olagunju
 */
public class Layer implements java.io.Serializable 
{
	private int sound = 1; //ACOUSTIC GRAND PIANO
	private int velocity = 64;
	
	private char[][] layerArray = new char[16][16]; //takes up the least memory (O or X)
	
	public Layer(){
		resetLayer();
	}
	
	public char getButtonChar(int x, int y){
		return this.layerArray[x][y];
	}
	
	public void setButtonChar(int x, int y, char ch){
		this.layerArray[x][y] = ch;
	}
	
	public char[] selectColumn(int x){
		return this.layerArray[x]; //column is accessed strangely
	}
	
	public char[][] returnLayerArray(){
		return layerArray;
	}
	
	public void setLayerArray(char[][] layerArray){
		this.layerArray = layerArray;
	}
	
	public int getSound(){
		return this.sound;
	}
	
	public void setSound(int currentSound){
		this.sound = currentSound;
	}
	
	public void resetLayer(){
		for(int i=0; i<this.layerArray.length; i++){
			for(int j=0; j<this.layerArray[i].length; j++){
				this.layerArray[i][j] = 'X';
			}
		}
	}

	public void setVelocity(int velocity) {
		this.velocity = velocity;
	}

	public int getVelocity() {
		return velocity;
	}

}

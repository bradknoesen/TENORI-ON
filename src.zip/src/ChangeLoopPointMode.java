/*
 * Changes where in the matrix the clockHand runs to.
 * 
 * @David Olagunju
 */
public class ChangeLoopPointMode implements Mode {
    private int loopPoint = 16;
    public ChangeLoopPointMode() {
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button) {
    	   button.getTenori().columnHighLight(button.getYCoord()); //X coord 
    	   
    	   String temp = String.valueOf(button.getYCoord()+1);
    	   this.loopPoint = Integer.parseInt(temp);
    	   
    	   Device.getInstance().getTenori().LCD.setText(temp);
    }
    
	@Override
	public void okButtonOperation() {
		System.out.println("LoopPoint has been set to " + this.loopPoint);
		Device.getClockHand().setLoopPoint(this.loopPoint);
		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
}

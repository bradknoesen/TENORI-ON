import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/*
 * Class for Sound button methods. 
 * @authors Bradley Knoesen, Presley Kode, Kate Mawbey, Eneida Morina, David Olagunju.
 */
class SoundButton extends JToggleButton
{
    private static final long serialVersionUID = 1L;

    private final int x;
    private final int y;
    private final Tenori te;
    public String value;
    
    private boolean clicked = false;
    
    private static ArrayList<SoundButton> buttonsSelected = new ArrayList<SoundButton>();

    /*
     * SoundButton constructor
     * @authors Bradley Knoesen, Presley Kode, Kate Mawbey, Eneida Morina, David Olagunju.
     */
    public SoundButton(int x, int y, Tenori te, String val)
    {
    	this.x = x;
    	this.y = y;
    	this.te = te;
    	this.setContentAreaFilled(false);
    	this.setBorderPainted(false);
    	this.setFocusPainted(false);
    	this.setEnabled(false);
    	this.setIcon(new ImageIcon("img/white.png"));
    	this.setSelectedIcon(new ImageIcon("img/orange.png"));
		this.value = val;
    	
    	addMouseListener(new MouseAdapter()
    	{
    	    		
            public void mouseClicked(MouseEvent e) 
            {
                SoundButton buttonClicked = (SoundButton)e.getSource();
                Device.getInstance().getMode().soundButtonOperation(buttonClicked);
            }
    	}
    	);
    }
   
    /*
     * An array that is populated with buttons that have been clicked on
     * @author David Olagunju.
     */
    public static ArrayList<SoundButton> getButtonsSelected()
    {
        return buttonsSelected;
    }
    
    /*
     * add buttons to the buttonsSelected array
     * @author Presley Kode
     */
    public static void addButtonsSelected(SoundButton b){
        buttonsSelected.add(b);
    }

    /*
     * removes buttons from the buttonsSelected array 
     * @author Bradley Knoesen
     */
    public static void removeButtonsSelected(SoundButton b){
        buttonsSelected.remove(b);
    }
 
    /*
     * clear the array holding buttons that have been clicked on
     * @authors Kate Mawbey
     */   
    public static void clearButtonsSelected(){
        buttonsSelected.clear();
    }

    /*
     * returns the X coordinates of a soundbutton
     * @authors Eneida Morina
     */
    public int getXCoord()
    {
        return this.x;
    }
    
    /*
     * returns the Y coordinates of a soundbutton
     * @authors Eneida Morina
     */
    public int getYCoord()
    {
        return this.y;
    }
    
    
    public Tenori getTenori()
    {
    	return this.te;
    }

    public String getVal(){
    	return this.value;
    }

    public boolean getState(){
    	return this.clicked;
    }
    
    
    public void On()
    {
    	if(!clicked)
    	{
    		this.setSelected(true);
    		clicked = true;
    	}
    }
    
    public void Off()
    {
    	if(clicked)
    	{
    		this.setSelected(false);
    		clicked = false;
    	}
    } 
}

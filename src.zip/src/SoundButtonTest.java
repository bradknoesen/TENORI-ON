import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * 
 * @author David Olagunju
 * @author Presley Kode
 *
 */
public class SoundButtonTest {
	public Tenori GUI;
	public SoundButton sound;
	
	
	@Before
	public void setUp() throws Exception {
		GUI = Tenori.getInstance();
		sound = new SoundButton(0, 0, GUI,"");
	}

	@After
	public void tearDown() throws Exception {
		GUI = null;
		sound = null;
	}
	
	/*
	 * Test of get buttons selected method, of class SoundButton
	 */
	@Test
	public void testGetButtonsSelected() {
		System.out.println("getButtonsSelected");
		
		//the size of the button before an button is added to 
		assertEquals("The size of the array storing the buttons clicked on before any button is clicked on should be 0", 0, sound.getTenori().matrix[1][1].getButtonsSelected().size());
		sound.getTenori().matrix[1][1].addButtonsSelected(new SoundButton(1,1,GUI,""));		
		assertEquals("The size of the array storing the buttons clicked after a button is added should be 1", 1, sound.getTenori().matrix[1][1].getButtonsSelected().size());
	}
}
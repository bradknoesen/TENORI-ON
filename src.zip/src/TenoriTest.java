import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


/*
 * Tenori Test Class
 * 
 * @author David Olagunju
 * @author Presley Kode
 */
public class TenoriTest {
	public Tenori GUI;
	
	@Before
	public void setUp() throws Exception {
		GUI = Tenori.getInstance();
	}
	
	@After
	public void tearDown() throws Exception {
		GUI = null;
	}
	
	/*
	 * Test of L1 method, of class Tenori
	 */
	@Test
	public void testL1() {
		System.out.println("L1");		
		//A button should not be null if it has been created
		assertFalse("If the L1 button has been created it should not be null", GUI.L1 == null);

	}
}
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * ClockHand thread class runs the clockhand when the Tenori Device is in performance mode
 * 
 * @author David Olagunju
 */
public class ClockHand implements Runnable {

    private int loopSpeed;
    private int loopPoint;
    public AtomicBoolean shutdown = new AtomicBoolean();

    /*
     * Constructor for clockHand the containing variables that the clockHand references
     */
    public ClockHand (){
        this.loopSpeed = 100;
        this.loopPoint = 16;
    }
    
    @Override
    public void run() {
        System.out.println("Clockhand thread started");
 
        while(!shutdown.get()) {

            for (int i=0; i<loopPoint; i++){
            	Device.getInstance().getTenori().clockHandHighLight(i);
            	
            	for (int j =0;j<Device.getInstance().getLayers().length; j++)
            	{
            		for (int k = 0; k<Device.getInstance().getLayer(j).selectColumn(i).length;k++)
            		{
            			if (Device.getInstance().getLayer(j).selectColumn(i)[k] == 'O')
            			{
            				Device.getInstance().getMediaPlayer().outputSound(40+k, j);
            			}
            		}
            			
            	}
 
                if (shutdown.get()){
                	break;
                }

                //Setting in the loopSpeed variable - 60000 ms is 1 minute
                try {
                	Thread.sleep(60000/loopSpeed);
                } catch (InterruptedException e) {
                	e.printStackTrace();
                }
            }
        }
        
        //Clear matrix after clockHand ends (End of While loop)
    	for (int j = 0; j < 16; j++){ //column
    		for (int k = 0; k < 16; k++ ) { //row
    			Device.getInstance().getTenori().matrix[j][k].Off();
    		}
    	}      
    }    
	
    /*
     * Returns the loopPoint integer
     */
    public int getLoopPoint(){
    	return loopPoint;
    }
    
    /*
	 *  Sets the loopPoint variable value using loopP value defined in the parameters
	 */
    public void setLoopPoint(int loopP){
    	this.loopPoint = loopP;
    }
        
    /*
     * Returns the loopSpeed integer
     */
    public int getLoopSpeed(){
    	return loopSpeed;
    }
    
    /*
     * Sets the loopSpeed variable value using loopS value defined in the parameters
     */
    public void setLoopSpeed(int loopS){
    	this.loopSpeed = loopS;
    }
}
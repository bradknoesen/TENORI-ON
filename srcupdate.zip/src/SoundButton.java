import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/*
 * Class for Sound button methods. 
 * @authors Bradley Knoesen, Presley Kode, Kate Mawbey, Eneida Morina, David Olagunju.
 */
class SoundButton extends JToggleButton
{
	private static final long serialVersionUID = 1L;

    private final int x;
    private final int y;
    private final Tenori te;
    private int velocity = 60;
	public String value;
    
    private boolean clicked = false;
    
    private static ArrayList<SoundButton> buttonsSelected = new ArrayList<SoundButton>();

    public SoundButton(int x, int y, Tenori te, String val)
    {
    	this.x = x;
    	this.y = y;
    	this.te = te;
    	this.setContentAreaFilled(false);
    	this.setBorderPainted(false);
    	this.setFocusPainted(false);
    	this.setEnabled(false);
    	this.setIcon(new ImageIcon("img/white.png"));
    	this.setSelectedIcon(new ImageIcon("img/orange.png"));
		this.value = val;
    	
    	addMouseListener(new MouseAdapter()
    	{
    	    		
            public void mouseClicked(MouseEvent e) 
            {
                SoundButton buttonClicked = (SoundButton)e.getSource();
                Device.getInstance().getMode().soundButtonOperation(buttonClicked);
            }
    	}
    	);
    }
   
    public static ArrayList<SoundButton> getButtonsSelected()
    {
        return buttonsSelected;
    }
    
   
    public static void addButtonsSelected(SoundButton b){
        buttonsSelected.add(b);
    }

   
    public static void removeButtonsSelected(SoundButton b){
        buttonsSelected.remove(b);
    }

   
    public static void clearButtonsSelected(){
        buttonsSelected.clear();
    }

   
    public int getXCoord()
    {
        return this.x;
    }
    
    
    public int getYCoord()
    {
        return this.y;
    }
    
    public Tenori getTenori()
    {
    	return this.te;
    }

	public String getVal()
    {
    	return this.value;
    }

    public boolean getState()
    {
    	return this.clicked;
    }
    
    
    public void On()
    {
    	if(!clicked)
    	{
    		this.setSelected(true);
    		clicked = true;
    	}
    }
    
    public void Off()
    {
    	if(clicked)
    	{
    		this.setSelected(false);
    		clicked = false;
    	}
    } 
    
    public int getVelocity(){
    	return this.velocity;
    }
    
    public void setVelocity(int vel){
    	this.velocity = vel;
    }
}

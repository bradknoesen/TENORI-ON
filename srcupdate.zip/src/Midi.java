import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

/*
 * @authors Bradley Knoesen, Presley Kode, David Olagunju
 */
public class Midi implements Runnable {
	
	private final static int FUDGE_FACTOR = 10;
	private int CHANNEL = 1; //Channel 9 for Percussions
	private int note = 50;
	private int velocity = 60;
	private int program = 1;
	
	Synthesizer synth;
    
	public Midi(int note, int velocity, int program, int CHANNEL){
    	this.note = note;
    	this.velocity = velocity;
    	this.program = program;
    	this.CHANNEL = CHANNEL;
    }

    public void run()
    {
        synth = this.getSynthesizer();
        this.playInstrument();

    }


    public Synthesizer getSynthesizer() {
        Synthesizer synthesizer = null;
        try {
            synthesizer = MidiSystem.getSynthesizer();
            synthesizer.open();
        } catch (Exception ex) {
            System.out.println(ex); System.exit(1);
        }
        return synthesizer;
    }


    /*
     * Delay for a number of milliseconds.
     */
    public void delay( int ms ) {
        try {
            Thread.sleep( ms );
        } catch( Exception ex ) {
            Thread.currentThread().interrupt();
        }
    }

    public void playInstrument() {
        MidiChannel[] midiChannels = synth.getChannels();
        MidiChannel midiChannel = midiChannels[ CHANNEL ];
        Instrument[] instruments = synth.getDefaultSoundbank().getInstruments();

        synth.loadInstrument(instruments[ program ]);
        midiChannel.programChange( program );
        midiChannel.noteOn(note, velocity);
        delay(FUDGE_FACTOR * velocity);
        midiChannel.noteOff(note, velocity);

    }
	
} 

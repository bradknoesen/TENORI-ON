
 
/*
 * Class for Load Mode which contains methods to assist in loading files.   
 * Instance of this class is created when R3 is clicked. 
 * @authors Kate Mawbey, Eneida Morina
 */
public class LoadMode implements Mode{
    private static String message = "";

    public LoadMode(){

    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }
    
    @Override
    public void soundButtonOperation(SoundButton button) 
    {
	modeLCD(button.getVal());
	Device.getInstance().getTenori().LCD.setText(message);
    }

	@Override
	public void okButtonOperation() {
		Device.getInstance().getTenori().loadFile(message);
		System.out.println("Filed loaded");
		Device.getInstance().getTenori().LCD.setText(message);
		message ="";

		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
        public void modeLCD(String Val){
		message = message + Val;
    }
}


public class ShopBoyMode implements Mode {

	@Override
	public void soundButtonOperation(SoundButton button) {
		// TODO Auto-generated method stub

	}

	@Override
	public void okButtonOperation() {
		// TODO Auto-generated method stub

	}

}

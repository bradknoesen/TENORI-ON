import javax.sound.midi.Instrument;

/*
 * Device acts as the back end of the GUI (tenori).It uses the singleton design pattern to enable methods 
 * to be referenced by various other classes using a single instance.
 * 
 * @authors Bradley Knoesen, Presley Kode, Kate Mawbey, Eneida Morina, David Olagunju.
 */
public class Device
{
	
    private volatile static Device instance = null;
    private Mode mode = new OffMode();
    private Layer[] layers = new Layer[16];
    private Layer currentLayer; // to be changed
    private Tenori tenori;
    private static ClockHand clockHand;
    private Midi midi;
    
    /*
     * Constructor to create a new Device with all the variables needed to 
     * 
     * @authors Kate Mawbey, Eneida Morina
     */  
    public Device(){
    	mode = new OffMode();
    	for (int n = 0; n < 16; n++) {
    		layers[n] = new Layer();
    	}
    	tenori = Tenori.makeGUI();
    }
    
    /*
     * Thread Safe Method to returns Device only if there isn't an instance already created
     * 
     * @authors David Olagunju.
     */ 
    public static Device getInstance(){
    	if(instance == null){
    		synchronized (Device.class){
    			if(instance == null){            
    				instance = new Device();
    			}
    		}
    	}
    	return instance;
    }
    
    /*
     * Sets the Mode variable value using mode value defined in the parameters
     * 
     * @authors Bradley Knoesen
     */
    public void setMode(Mode mode) {
        this.mode = mode;
    }
    
    
    /*
     * Returns the Mode variable
     * 
     * @authors Bradley Knoesen
     */
    public Mode getMode() {
        return mode;
    }

    /*
     * Returns the Tenori
     * 
     * @authors Presley Kode
     */
    public Tenori getTenori()
    {
        return tenori;
    }

    /*
     * Returns the clockHand variable
     * 
     * @authors Presley Kode.
     */
   public static ClockHand getClockHand(){
   	return clockHand;
   }

   /*
    * Sets the clockHand variable value using ClockHand value defined in the parameters
    * 
    * @authors Presley Kode.
    */
   public static void setClockHand(ClockHand clockH){
   	clockHand = clockH;
   }

   public Midi getMidi(){
	   return midi;
   }
   
   /*
    * Resets the Device to a default state 
    * 
    * @David Olagunju, Bradley Knoesen
    */
   	public void defaultState() {
	   mode = new OffMode();
	   setClockHand(new ClockHand());
	   tenori.LCD.setText(null);
	   tenori.matrix[1][1].clearButtonsSelected();
   }
   	
	public Layer[] getLayers()
	{
		return this.layers;
	}
	
	public Layer getLayer(int i)
	{
		return this.layers[i];
	}

	public void setCurrentLayer(Layer layer)
	{
		this.currentLayer = layer;
	}
	
	public void setCurrentLayer(int index)
	{
		this.currentLayer = this.layers[index];
	}
	
	public Layer getCurrentLayer()
	{
		return this.currentLayer;
	}

	public Instrument[] getMediaPlayer() {
		// TODO Auto-generated method stub
		return null;
	}
}
/*
 * Class for Save Mode which contains methods to assist in saving files.   
 * Instance of this class is created when R2 is clicked. 
 * --Isn't currently working--
 *
 * @authors Kate Mawbey, Eneida Morina
 */
 
public class SaveMode implements Mode{
    private static String message = "";
    public SaveMode(){
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }
    

    @Override
    public void soundButtonOperation(SoundButton button) 
    {
	modeLCD(button.getVal());
	Device.getInstance().getTenori().LCD.setText(message); //Tooltips could be set in here (ran out of time)
    }
    
	@Override
	public void okButtonOperation() {
		Device.getInstance().getTenori().saveFile(message);
		System.out.println("Filed saved");
		Device.getInstance().getTenori().LCD.setText(message);
		message ="";

		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
	
        public void modeLCD(String Val){
		message = message + Val;
    }

}
/*
 * Changes the volumn on the row and column of the selected button.
 *
 * @authors Bradley Knoesen, Presley Kode, David Olagunju
 */
public class ChangeVelocityMode implements Mode {

	int velocity = 60;
	String temp;	
	
    public ChangeVelocityMode() {
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button) 
    {        
        button.getTenori().modeButtonHighLight(button.getXCoord(), button.getYCoord());
        
        velocity = (int) Math.round(((button.getXCoord()*16) + button.getYCoord())/2); //0 - 127
        
          	
        for (int k = 0; k < 16; k++ ){
        	Device.getInstance().getTenori().getButton(button.getXCoord(), k).setVelocity(velocity);
        	Device.getInstance().getTenori().getButton(k, button.getYCoord()).setVelocity(velocity);
        }
        	
        String temp = String.valueOf(velocity);
        
        Device.getInstance().getTenori().LCD.setText(temp);   
   
    }

	@Override
	public void okButtonOperation() {
		System.out.println("Velocity has been set to " + this.velocity);
		//Device.getClockHand().setVelocity
		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
}
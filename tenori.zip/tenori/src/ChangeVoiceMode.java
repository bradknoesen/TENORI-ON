/*
 * Changes the instrument being played
 * 
 * @authors Bradley Knoesen, Presley Kode, David Olagunju
 */
public class ChangeVoiceMode implements Mode {
	
	int voice = 1;
	String voiceName; //Accessing the clockHand variable to check the current Instrument 
	
    public ChangeVoiceMode() {
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button) 
    {        
        button.getTenori().modeButtonHighLight(button.getXCoord(), button.getYCoord());
        
        //128 conventional sounds + 47 Percussion sounds
        voice = (int) Math.round(((button.getXCoord()*16) + button.getYCoord())/1.46); //for functionality the percussions were ignored
        
        if (voice > 128){
        	//Device.getClockHand().setIsPercuss(true);
        	voice = (int) Math.round(((button.getXCoord()*16) + button.getYCoord())/1.46) - 94; //adding it so it can go from 35 - 81
        	System.out.println(this.voice);
        }
        
        
        String voiceName = Device.getClockHand().getVoiceName(voice);
        
        Device.getInstance().getTenori().LCD.setText(voiceName);
        
    }

	@Override
	public void okButtonOperation() {
		System.out.println("Voice has been set to " + this.voice);
	    Device.getClockHand().setVoice(voice);
		Device.getInstance().getTenori().LCD.setText( Device.getClockHand().getVoiceName(voice));
		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
}
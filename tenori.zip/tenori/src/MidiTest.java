import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import javax.sound.midi.Instrument;
import javax.sound.midi.Synthesizer;
import static org.junit.Assert.*;

/**
 * 
 * @author David Olagunju
 * @author Presley Kode
 *
 */

public class MidiTest {

		public Midi Midi;
		
		
		@Before
		public void setUp() throws Exception {
			Midi = new Midi(10,10,10);
		}

		@After
		public void tearDown() throws Exception {
			Midi = null;
		}
		
/*
 * Test of getSynthesizer method, of class Midi
 */
	@Test
	public void testGetSynthesizer() {
		System.out.println("Get Synthesizer");
		Synthesizer synthesizer = Midi.getSynthesizer();
		//the synthesizer should contain element(s) after being created
		assertFalse("If the Synthesizer has been created it should not be null",synthesizer == null); 
	}
	/*
	 * Test of playerInstrument method, of class Midi
	 */
	@Test
	public void testPlayInstrument() {
		System.out.println("Play Instrument");
		Midi.playInstrument();
		Synthesizer synthesizer = Midi.getSynthesizer();
		Instrument[] instrument = synthesizer.getDefaultSoundbank().getInstruments();
		//the instrument array must contain element(s) after being created
		assertFalse("If the instrument has been created it should not be null",instrument == null); 
	}

}
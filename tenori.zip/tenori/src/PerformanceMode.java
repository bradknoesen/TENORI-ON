/*
 * Default mode set when tenori device is turned on.
 * Clockhand starts running in this mode. 
 *
 * @David Olagunju and Bradley Knoesen
 */
public class PerformanceMode implements Mode {

    public PerformanceMode() {
    	if (Device.getClockHand() == null){
    		Device.setClockHand(new ClockHand());
    		(new Thread(Device.getClockHand())).start();
    	} else {
    		Device.getClockHand().shutdown.set(false);
    		(new Thread(Device.getClockHand())).start();
    	}
    }
    

    @Override
    public void soundButtonOperation(SoundButton button) 
    {
        if(!button.getState()) {
        	button.On();
            SoundButton.addButtonsSelected(button);
            //Device.getInstance().getCurrentLayer().setButtonChar(button.getXCoord(), button.getYCoord(), 'O');
        }
        else {
        	button.Off();
            SoundButton.removeButtonsSelected(button);
            //Device.getInstance().getCurrentLayer().setButtonChar(button.getXCoord(), button.getYCoord(), 'X');
        }
    }

    
    @Override
    public void okButtonOperation(){
    	System.out.println("Tenori has been set to ShopBoy mode");
				
		//Check if the matrix gets cleared 
		// Shop boy mode
		// New skins to Tenori
		// Networking master and slave
		// change velocity
		// change layer
		
		Device.getInstance().setMode(new ShopBoyMode());
    }
}
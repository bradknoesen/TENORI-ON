import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;


public class MediaPlayer {
	

	private Synthesizer synth;
	private MidiChannel[] midiChannelArr;
	private final static int PERCUSSION_CH = 9;
	private final static int TEMP_CH = 3;
	
	public MediaPlayer()
	{
		try{
			this.synth = MidiSystem.getSynthesizer();
			this.synth.open();
		}
		catch (Exception e){System.out.println("Error: " + e);
							System.exit(1);
		}
		midiChannelArr = synth.getChannels();
	}
	
	public void outputSound(int note, int layerNum)
	{
		int voice = Device.getInstance().getLayer(layerNum).getSound();
		int velocity = Device.getInstance().getLayer(layerNum).getVelocity();
		Sounds sound;
		if(voice >= 128)
		{
			/////////////////////////////////////////////////////////////////
			System.out.println(note);
			System.out.println(voice);
			note = voice - 94; 				//setting it to be 35 and then going upwards
			System.out.println(note);
			/////////////////////////////////////////////////////////////////
			sound = new Sounds(this.synth, this.midiChannelArr[ PERCUSSION_CH], voice, note, velocity); 
			//list of midi percussion sounds to be made
			
		}else {
			sound = new Sounds(this.synth, this.midiChannelArr[ TEMP_CH ], voice, note, velocity);
		}
		
		(new Thread(sound)).start();
		
	}
		
	public Synthesizer getSynth()
	{
		return this.synth;
	}
	
	public class Sounds implements Runnable {
		private int note = 50;
		private int velocity = 120;
		private int voice = 1;
		private Synthesizer synth;
		private MidiChannel midiChannel;
	
		public Sounds(Synthesizer synth, MidiChannel midiChannel, int voice, int note, int velocity)
		{
			this.note = note;
			this.velocity = velocity;
			this.synth = synth;
			this.midiChannel = midiChannel;
			this.voice = voice;
		
		}
		
		public void run()
		{
			Instrument[] voices = synth.getDefaultSoundbank().getInstruments();
			
			synth.loadInstrument(voices[voice]);
			midiChannel.programChange(voice);
			midiChannel.noteOn(note, velocity);
			
			delay(8*velocity);
			midiChannel.noteOff(note, velocity);
		}
		
		  public void delay(int ms){
		    	try{
		    		Thread.sleep(ms);
		    	} catch (Exception e) {
		    		Thread.currentThread().interrupt();
		    	}
		  }
		  
		  
	}
}


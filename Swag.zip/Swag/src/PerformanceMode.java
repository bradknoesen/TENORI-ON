/*
 * Default mode set when tenori device is turned on.
 * Clockhand starts running in this mode. 
 *
 * @David Olagunju and Bradley Knoesen
 */
public class PerformanceMode implements Mode {

    public PerformanceMode() {
    	if (Device.getClockHand() == null){
    		Device.setClockHand(new ClockHand());
    		(new Thread(Device.getClockHand())).start();
    	} else {
    		Device.getClockHand().shutdown.set(false);
    		(new Thread(Device.getClockHand())).start();
    	}
    }
    

    @Override
    public void soundButtonOperation(SoundButton button) 
    {
        if(!button.getState()) {
        	button.On();
            SoundButton.addButtonsSelected(button);
            Device.getInstance().getTempLayer().setButtonChar(button.getYCoord(), button.getXCoord(), 'O');
        }
        else {
        	button.Off();
            SoundButton.removeButtonsSelected(button);
            Device.getInstance().getTempLayer().setButtonChar(button.getYCoord(), button.getXCoord(), 'X');
        }
    }

    
    @Override
    public void okButtonOperation(){
    	
    	
    }
}
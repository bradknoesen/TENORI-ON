/*
 * Changes the speed of the clockhand and is maxed out as 160 beats per minutes.
 * 
 * @authors David Olagunju and Bradley Knoesen
 */
public class ChangeLoopSpeedMode implements Mode 
{
	int loopSpeed = 10;
    public ChangeLoopSpeedMode(){
    	if (Device.getClockHand() != null){
    		Device.getClockHand().shutdown.set(true);
    	}
    }

    @Override
    public void soundButtonOperation(SoundButton button) {  	
    	
        button.getTenori().modeButtonHighLight(button.getXCoord(), button.getYCoord());
        
        String temp = String.valueOf(Math.round(((button.getXCoord()*16) + button.getYCoord())/1.59)); //Columns*16 plus the row number
        																								//256/1.59 = max of 160 bpm (beats per minute)
        this.loopSpeed =  Integer.parseInt(temp); //setting loopSpeed value 
        
        Device.getInstance().getTenori().LCD.setText(temp);       
    }


	@Override
	public void okButtonOperation() {
		System.out.println("LoopSpeed has been set to " + this.loopSpeed);
		Device.getClockHand().setLoopSpeed(this.loopSpeed);
		
		//Makes selected reappear after Mode operations 
		for (SoundButton obj: Device.getInstance().getTenori().matrix[1][1].getButtonsSelected()){
			obj.setSelected(true);
		}
		
		Device.getInstance().setMode(new PerformanceMode());
	}
}

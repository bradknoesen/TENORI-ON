import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/*
 * @author David Olagunju, Presley Kode
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({TenoriTest.class})
@Suite.SuiteClasses({SoundButtonTest.class})
@Suite.SuiteClasses({MidiTest.class})
public class TestSuite{
	
}
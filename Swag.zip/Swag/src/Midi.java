import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

public class Midi implements Runnable {
	
	private final static int FUDGE_FACTOR = 10;
	private final static int CHANEL = 1;
	private final static int PERCUSSION_CHANNEL =    9;
	
	private int note = 50;
	private int velocity = 120;
	private int program = 9;
	
	Synthesizer synth;
    
	public Midi(int note, int velocity, int program){
		this.note = note;
		this.velocity = velocity;
		this.program = program;
    }
	
	
	public void run(){
		synth = this.getSynthesizer();
		this.playInstrument();
	}

    public Synthesizer getSynthesizer(){
    	Synthesizer synth = null;
    	try{
    		synth = MidiSystem.getSynthesizer();
    		synth.open();
    	} catch( Exception e ){
    		System.out.println( e ); System.exit( 1 );
    	}
    	return synth;
    }
        
    public void delay(int ms){
    	try{
    		Thread.sleep(ms);
    	} catch (Exception e) {
    		Thread.currentThread().interrupt();
    	}
    }
    
    
    public void playInstrument(){
    	MidiChannel[] midiChannels = synth.getChannels();
    	MidiChannel midiChannel = midiChannels[ CHANEL ];
    	Instrument[] instruments =
    		synth.getDefaultSoundbank().getInstruments();
	
    	synth.loadInstrument( instruments[ program ] );
    	midiChannel.programChange( program );
    	midiChannel.noteOn ( note, velocity );
    	delay( FUDGE_FACTOR * velocity );
    	midiChannel.noteOff( note, velocity );
    }
    
    /*
     * Play percussion instrument.
     */
    public void playPercussion() {
       MidiChannel[] midiChannels = synth.getChannels();
       MidiChannel   midiChannel  = midiChannels[ PERCUSSION_CHANNEL ];
       midiChannel.noteOn ( note, velocity );
       delay( FUDGE_FACTOR * velocity );
       midiChannel.noteOff( note, velocity );
    }
} 
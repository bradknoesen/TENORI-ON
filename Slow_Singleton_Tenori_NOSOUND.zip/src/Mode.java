public interface Mode {

    public abstract void soundButtonOperation(SoundButton button);

}

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

public class Midi {
	
	private final static int FUDGE_FACTOR = 10;    
    
	public Midi(){
    	
    }
	  
    public void delay( int ms ){
	try{
	    Thread.sleep( ms );
	} catch(Exception e){
	    Thread.currentThread().interrupt();
        }
    }

    public Synthesizer getSynthesizer(){
	Synthesizer synthesizer = null;
	try{
	    synthesizer = MidiSystem.getSynthesizer();
	    synthesizer.open();
	} catch( Exception e ){
	    System.out.println( e ); System.exit( 1 );
	}
	return synthesizer;
    }
    
    
    //public get paino - 0, 127
    
    //public get drums - 128, 176
  //synthesizer.getDefaultSoundbank().getInstruments()[1].getName();
    //midi online
    
    
    public void playInstrument( Synthesizer synthesizer 
				, int channel
				, int program
				, int note
				, int velocity ){

	MidiChannel[] midiChannels = synthesizer.getChannels();
	MidiChannel midiChannel = midiChannels[ channel ];
	Instrument[] instruments =
	    synthesizer.getDefaultSoundbank().getInstruments();
	//synthesizer.getDefaultSoundbank().getInstruments()[1].getName();
	
	synthesizer.loadInstrument( instruments[ program ] );
	midiChannel.programChange( program );
	midiChannel.noteOn ( note, velocity );
	delay( FUDGE_FACTOR * velocity );
	midiChannel.noteOff( note, velocity );
    }
    
    
} 


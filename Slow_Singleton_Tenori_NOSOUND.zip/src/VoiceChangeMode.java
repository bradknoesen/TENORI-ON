public class VoiceChangeMode implements Mode {

    public VoiceChangeMode() {
    }

    @Override
    public void soundButtonOperation(SoundButton button) 
    {

        
    	System.out.println("VoiceChangeMode");
        button.getTenori().modeButtonHighLight(button.getXCoord(), button.getYCoord());
        
        //after l1 every button on the Device is associated with an intstrument
        //128 and 47
        //the name is put in the Display
        //press okay then it goes back to performance mode
    }

}

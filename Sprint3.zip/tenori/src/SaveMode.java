public class SaveMode implements Mode{
    
    public SaveMode(){

    }

    @Override
    public void soundButtonOperation(SoundButton button) 
    {

    }
    
    @Override
    public void okButtonOperation(){}
	
    
}
public interface Mode {

    public abstract void soundButtonOperation(SoundButton button);

    public abstract void okButtonOperation();

}
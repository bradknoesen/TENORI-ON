public class LoadMode implements Mode{
    
    public LoadMode(){

    }
    
    @Override
    public void soundButtonOperation(SoundButton button) 
    {

    }

    @Override
    public void okButtonOperation(){}
}
import java.util.concurrent.atomic.AtomicBoolean;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

/*
 * ClockHand thread class runs the clockhand when the Tenori Device is in performance mode
 * 
 * @author David Olagunju
 */
public class ClockHand implements Runnable {

    private int loopSpeed;
    private int loopPoint;
    private int voice = 1;
    private int CHANNEL = 1;
    public AtomicBoolean shutdown = new AtomicBoolean();


    /*
     * Constructor for clockHand the containing variables that the clockHand references
     */
    public ClockHand (){
        this.loopSpeed = 100;
        this.loopPoint = 16;
    }
    
    @Override
    public void run() {
        System.out.println("Clockhand thread started");
 
        while(!shutdown.get()) {

            for (int i=0; i<loopPoint; i++){
            	Device.getInstance().getTenori().clockHandHighLight(i);
 
            	for (int j=0; j<SoundButton.getButtonsSelected().size(); j++){
            		SoundButton button = SoundButton.getButtonsSelected().get(j);
            		
            		//Sound is made here
            		if(button.getYCoord() == i){										
            			(new Thread(new Midi(60 - button.getXCoord(), button.getVelocity(), voice, CHANNEL))).start();
            		}
            	}
            		
                if (shutdown.get()){
                	break;
                }

                //Setting in the loopSpeed variable - 60000 ms is 1 minute
                try {
                	Thread.sleep(60000/loopSpeed);
                } catch (InterruptedException e) {
                	e.printStackTrace();
                }
            }
        }
        
        //Clear matrix after clockHand ends (End of While loop)
    	for (int j = 0; j < 16; j++){ //column
    		for (int k = 0; k < 16; k++ ) { //row
    			Device.getInstance().getTenori().matrix[j][k].Off();
    		}
    	}      
    }    
	
    /*
     * Returns the loopPoint integer
     */
    public int getLoopPoint(){
    	return loopPoint;
    }
    
    /*
	 *  Sets the loopPoint variable value using loopP value defined in the parameters
	 */
    public void setLoopPoint(int loopP){
    	this.loopPoint = loopP;
    }
        
    /*
     * Returns the loopSpeed integer
     */
    public int getLoopSpeed(){
    	return loopSpeed;
    }
    
    /*
     * Sets the loopSpeed variable value using loopS value defined in the parameters
     */
    public void setLoopSpeed(int loopS){
    	this.loopSpeed = loopS;
    }
    
    /*
     * Returns the Voice integer
     */
    public int getVoice(){
    	return voice;
    }
    
    /*
     * Sets the voice variable value using the voice value defined in the parameters
     */
    public void setVoice(int voice){
    	this.voice = voice;
    }
    
    /*
     * Returns the name of the Instrument linked to the number and CHANNEL
     */
    public String getVoiceName(int voice, int CHANNEL){
    	Synthesizer synthesizer = null;
        try {
            synthesizer = MidiSystem.getSynthesizer();
            synthesizer.open();
        } catch (Exception ex) {
            System.out.println(ex); System.exit(1);
        }
        //For Percussion
        
        
        return synthesizer.getDefaultSoundbank().getInstruments()[voice].getName();
    }
    
    /*
     * Sets the CHANNEL variable value using the int CHANNEL value defined in the parameters
     */
    public void setCHANNEL(int CHANNEL){
    	this.CHANNEL = CHANNEL;
    }

	public int getCHANNEL() {
		return CHANNEL;
	}
}